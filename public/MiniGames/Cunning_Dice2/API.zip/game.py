import random



def dice() -> int:
    return random.randint(1,6)

class agent:
    def __init__(self, uid : int, name : str, strategy : any):
        """
        bool strategy(int score, int turn)
        1 to stand
        0 to seat
        """
        
        self.id : int = uid
        self.name : str = name
        self.score : int = 0
        self.fscore : int = 0
        self.play = strategy



def run_round(agents : list) -> None:
    

    in_game = []
    turn = 0
    count = 0

    in_game = agents[:]
    count = len(agents)

    while count != 0:
        d = dice()
        if(d == 1):
            for agent in in_game:
                agent.score = 0
            break
        
        turn += 1
        ind_help = 0
        for i in range(count):
            i -= ind_help
            in_game[i].score += d
            x = in_game[i].play(in_game[i].score, turn)
            if(x == 0):
                in_game.pop(i)
                count -= 1
                ind_help += 1
        
    for agent in agents:
        agent.fscore += agent.score
        agent.score = 0
            

def game_summary(agents : list) -> None:
    for agent in agents:
        print(agent.name, ":", agent.fscore)


### strategies

def user_strategy_builder(sc : int = None, tu : int = None) -> any:
    def user_strategy(score : int, turn : int) -> bool:
        if(sc != None and score >= sc):
            return 0
        if(tu != None and turn >= tu):
            return 0
        
        return 1
    return user_strategy
    

def noob1_strategy(score : int, turn : int) -> bool:
    return random.randint(0,1)

def noob2_strategy(score : int, turn : int) -> bool:
    return random.choices([0, 1], weights=[1/3, 2/3], k=1)[0]

def noob3_strategy(score : int, turn : int) -> bool:
    return random.choices([0, 1], weights=[1/6, 5/6], k=1)[0]

def smart1_strategy(score : int, turn : int) -> bool:
    if turn >= 4:
        return 0
    return 1

def smart2_strategy(score : int, turn : int) -> bool:
    if turn >= 5:
        return 0
    return 1

def smart3_strategy(score : int, turn : int) -> bool:
    if turn >= 6:
        return 0
    return 1

def pro_strategy(score : int, turn : int) -> bool:
    if(score >= 20):
        return 0
    return 1

def setup_agents(ids : list) -> list:

    all = {1:agent(1, "Noob1", noob1_strategy),
        2:agent(2, "Noob2", noob2_strategy),
        3:agent(3, "Noob3", noob3_strategy),
        4:agent(4, "Smart1", smart1_strategy),
        5:agent(5, "Smart2", smart2_strategy),
        6:agent(6, "Smart3", smart3_strategy),
        7:agent(7, "Pro", pro_strategy)}
    
    agents = []
    for i in ids:
        agents.append(all[i])

    
    return agents

def run_game(agents : list, rounds : int) -> None:
    for i in range(rounds):
        run_round(agents)



