import requests as r
domain = "http://127.0.0.1:8000"

def run_game(ids , rounds, score = None, turn = None):
    
    ans = r.get(domain + "/run/", {"ids" : ''.join(str(i) for i in ids), "rounds" : rounds, "score" : score, "turn" : turn})
    return ans.json()

d = run_game([0,1,2,3,4,5,6,7],1000, score = None, turn = 4)

"""
ex:
api.com/run/
{"ids" : "12345", "rounds" : 1000, "score" : 10, "turn" : 5}

"""
"""

0 : user
1 : noob1
2 : noob2
3 : noob3
4 : smart1
5 : smart2
6 : smart3
7 : pro
"""