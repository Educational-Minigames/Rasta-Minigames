from typing import Optional
import game
from fastapi import FastAPI

app = FastAPI()


@app.get("/run/")
async def run(ids : str, rounds : int, turn : Optional[int] = None, score : Optional[int] = None):

    ids = list(ids)
    
    try:
        ids = list(map(int, ids))
    except:
        return {"error" : 1}
    for i in ids:
        if(i>8 or i<0):
            return {"error" : 1}

    if(rounds < 0):
        return {"error" : 1}



    if(0 in ids):
        
        if(score == None and turn == None):
            return {"error" : 1}
        if(score != None and score < 0):
            return {"error" : 1}
        if(turn != None and turn < 0):
            return {"error" : 1}
        
        ids.remove(0)
        agents = game.setup_agents(ids)
        our_player = game.agent(0, "Player", game.user_strategy_builder(score, turn))
        agents.append(our_player)

        

    else:
        agents = game.setup_agents(ids)
    
    game.run_game(agents, rounds)
    
    result = {"error" : 0}
    for agent in agents:
        result.update({agent.id : agent.fscore})

    return result
